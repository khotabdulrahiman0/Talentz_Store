import React from 'react'
// import TopBar from '../Layout/Topbar'
import Navbar from './Navbar'

const Header = () => {
  return (
    <header className='border-b border-b-gray-400'>
        {/* Topbar */}
        {/* <TopBar/> */}
         {/* Navbar */}
         <Navbar/>
          {/* Cart Drawer */}
    </header>
  )
}

export default Header